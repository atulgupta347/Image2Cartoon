#import
import cv2
import easygui
import matplotlib.pyplot as plt
import os
import tkinter as tk
from tkinter import *

#GUI Window
top = tk.Tk()
top.geometry("300x300")
top.title('Image2Cartoon!!!')
top.iconbitmap(r"C:\Personal Work\Python Projects\Image2Cartoon\favicon.ico")
top.configure(background='yellow')

#get image as an input
def uploadImage():
    ImagePath = easygui.fileopenbox()
    Convert2Cartoon(ImagePath)

#convert image to cartoon
def Convert2Cartoon(ImagePath):
    # read the image
    originalmage = cv2.imread(ImagePath)

    originalmage = cv2.cvtColor(originalmage, cv2.COLOR_BGR2RGB)
    ReSized1 = cv2.resize(originalmage, (960, 540))

    # converting an image to grayscale
    grayScaleImage = cv2.cvtColor(originalmage, cv2.COLOR_BGR2GRAY)
    ReSized2 = cv2.resize(grayScaleImage, (960, 540))

    # applying median blur to smoothen an image
    smoothGrayScale = cv2.medianBlur(grayScaleImage, 3)
    ReSized3 = cv2.resize(smoothGrayScale, (960, 540))

    # retrieving the edges for cartoon effect
    # by using thresholding technique
    getEdge = cv2.adaptiveThreshold(smoothGrayScale, 255,
                                    cv2.ADAPTIVE_THRESH_MEAN_C,
                                    cv2.THRESH_BINARY, 9, 9)

    ReSized4 = cv2.resize(getEdge, (960, 540))

    # applying bilateral filter to remove noise
    # and keep edge sharp as required
    colorImage = cv2.bilateralFilter(originalmage, 9, 300, 300)
    ReSized5 = cv2.resize(colorImage, (960, 540))

    # masking edged image with our "BEAUTIFY" image
    cartoonImage = cv2.bitwise_and(colorImage, colorImage, mask=getEdge)
    ReSized6 = cv2.resize(cartoonImage, (960, 540))

    # Plotting the whole transition
    images = [ReSized1, ReSized2, ReSized3, ReSized4, ReSized5, ReSized6]

    fig, axes = plt.subplots(3, 2, figsize=(8, 8), subplot_kw={'xticks': [], 'yticks': []},
                             gridspec_kw=dict(hspace=0.1, wspace=0.1))
    for i, ax in enumerate(axes.flat):
        ax.imshow(images[i], cmap='gray')

    save1 = Button(top, text="Save", command=lambda: save(ReSized6, ImagePath), padx=30, pady=5)
    save1.configure(background='#452f2f', foreground='white', font=('Lemonada', 10, 'bold'))
    save1.pack(side=TOP, pady=50)

    plt.show()

#save converted image
def save(ReSized6, ImagePath):
    newName = "output"
    path1 = os.path.dirname(ImagePath)
    extension = os.path.splitext(ImagePath)[1]
    path = os.path.join(path1, newName + ".jpeg")
    cv2.imwrite(path, cv2.cvtColor(ReSized6, cv2.COLOR_RGB2BGR))
    I = "Image saved by name " + newName + " at " + path
    tk.messagebox.showinfo(title=None, message=I)
# Image2Cartoon file upload button
upload=Button(top,text="Image2Cartoon",command=uploadImage,padx=8,pady=6)
upload.configure(background='#452f2f', foreground='white', font=('Lemonada', 10, 'bold'))
upload.pack(side=TOP, pady=50)

top.mainloop()



